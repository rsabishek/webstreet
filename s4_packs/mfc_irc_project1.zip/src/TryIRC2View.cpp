// TryIRC2View.cpp : implementation of the CTryIRC2View class
//

#include "stdafx.h"
#include "TryIRC2.h"

#include "TryIRC2Doc.h"
#include "TryIRC2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// CTryIRC2View

IMPLEMENT_DYNCREATE(CTryIRC2View, CView)

BEGIN_MESSAGE_MAP(CTryIRC2View, CView)
	//{{AFX_MSG_MAP(CTryIRC2View)
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_MESSAGE(IRCEDN_RETURNPRESSED, OnIrcMessageEdited)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2View construction/destruction

CTryIRC2View::CTryIRC2View()
{
	// TODO: add construction code here

}

CTryIRC2View::~CTryIRC2View()
{
}

BOOL CTryIRC2View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2View drawing

void CTryIRC2View::OnDraw(CDC* pDC)
{
	CTryIRC2Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2View diagnostics

#ifdef _DEBUG
void CTryIRC2View::AssertValid() const
{
	CView::AssertValid();
}

void CTryIRC2View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CTryIRC2Doc* CTryIRC2View::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CTryIRC2Doc)));
	return (CTryIRC2Doc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2View message handlers

void CTryIRC2View::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);

	if( nType != SIZE_MINIMIZED )
	{
		static const int iHeight = 18;

		m_wndMonitor.MoveWindow(0, 0, cx, cy - iHeight);
		m_wndUserText.MoveWindow(0, cy - iHeight, cx, iHeight);
	}
}

void CTryIRC2View::OnSetFocus(CWnd* pOldWnd) 
{
	CView::OnSetFocus(pOldWnd);
	m_wndUserText.SetFocus();
}

int CTryIRC2View::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	if( !m_wndMonitor.Create(WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_READONLY, CRect(), this, 100) )
		return -1;

	if( !m_wndUserText.Create(WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL, CRect(), this, 101) )
		return -1;

	m_wndMonitor.ModifyStyleEx(WS_EX_CLIENTEDGE, 0);
	m_wndUserText.ModifyStyleEx(0, WS_EX_STATICEDGE);

	m_wndMonitor.SendMessage(WM_SETFONT, (WPARAM)GetStockObject(SYSTEM_FIXED_FONT));
	m_wndUserText.SendMessage(WM_SETFONT, (WPARAM)GetStockObject(SYSTEM_FIXED_FONT));

	// set word-wrapping off
	m_wndMonitor.SetTargetDevice(NULL, 1);

	return 0;
}

void CTryIRC2View::SetDefaultTextColor(COLORREF rgb)
{
	CRichEditFormat f;

	f.dwMask = CFM_COLOR;
	f.crTextColor = rgb;

	m_wndMonitor.SendMessage(EM_SETCHARFORMAT, SCF_SELECTION, (LPARAM)&f);
}

LRESULT CTryIRC2View::OnIrcMessageEdited(WPARAM, LPARAM)
{
	CString s;

	m_wndUserText.GetWindowText(s);
	if( s.GetLength() == 0 )
		return 0;

	if( s[0] != '/' )
		s = "PRIVMSG " + m_sName + " :" + s;
	else
		s = s.Mid(1);

	if( g_ircSession )
		g_ircSession << irc::CIrcMessage(s);

	m_wndUserText.SetWindowText(_T(""));

	return 0;
}


void CTryIRC2View::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	static const COLORREF rgbNick = RGB(255,0,0);
	static const COLORREF rgbCmd = RGB(0,0,255);
	static const COLORREF rgbUnNicked = RGB(0,128,0);
	static const COLORREF rgbMsg = RGB(0,0,0);
	static const COLORREF rgbNotice = RGB(128,128,128);

	const irc::CIrcMessage* p = (const irc::CIrcMessage*)lHint;

	if( p )
	{
		m_wndMonitor.SetSel(-1, 0);
		m_wndMonitor.SendMessage(EM_SCROLLCARET);

		if( p->prefix.sNick.length() )
		{
			SetDefaultTextColor(rgbNick);
			m_wndMonitor.ReplaceSel((p->prefix.sNick + " ").c_str());
			SetDefaultTextColor(rgbCmd);
		}
		else
			SetDefaultTextColor(rgbUnNicked);

		m_wndMonitor.ReplaceSel((p->sCommand + " ").c_str());

		if( p->sCommand == "PRIVMSG" )
			SetDefaultTextColor(rgbMsg);
		else
			SetDefaultTextColor(rgbNotice);

		for(int i=0; i < p->parameters.size(); i++)
		{
			m_wndMonitor.ReplaceSel((p->parameters[i] + " ").c_str());
		}
		m_wndMonitor.ReplaceSel("\r\n");
	}
}

void CTryIRC2View::SetName(LPCTSTR lpszName)
{
	m_sName = lpszName;
}

LPCTSTR CTryIRC2View::GetName() const
{
	return m_sName;
}

void CTryIRC2View::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	m_wndMonitor.SetSel(-1, 0);
	m_wndMonitor.SendMessage(EM_SCROLLCARET);

	m_wndMonitor.Invalidate();
}


BOOL CTryIRC2View::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo) 
{
	BOOL rc = CView::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);

#if 0
	if( nID == 100 )
	{
		if( nCode == EN_SETFOCUS )
			HideCaret();
		else if( nCode == EN_KILLFOCUS )
			ShowCaret();
	}
#endif 

	return rc;
}

void CTryIRC2View::OnDestroy() 
{
	CView::OnDestroy();

	if( m_sName.GetLength() && m_sName[0] == '#' )
	{
		CString s;
		s.Format("PART %s", (const char*)m_sName);
		g_ircSession << CIrcMessage(s);
	}
}
