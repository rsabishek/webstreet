// TryIRC2View.h : interface of the CTryIRC2View class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRYIRC2VIEW_H__368D93D8_A26C_4F61_8AA9_A7E4477613D0__INCLUDED_)
#define AFX_TRYIRC2VIEW_H__368D93D8_A26C_4F61_8AA9_A7E4477613D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EditIrcMessageLine.h"

class CTryIRC2View : public CView
{
protected: // create from serialization only
	DECLARE_DYNCREATE(CTryIRC2View)
	CTryIRC2View();

// Attributes
public:
	CTryIRC2Doc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTryIRC2View)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint);
	virtual void OnInitialUpdate();
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	LPCTSTR GetName() const;
	void SetName(LPCTSTR lpszName);
	virtual ~CTryIRC2View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	struct CRichEditFormat : public CHARFORMAT
	{
		CRichEditFormat()
		{
			memset(this, 0, sizeof(CHARFORMAT));
			cbSize = sizeof(CHARFORMAT);
		}
	};

// Generated message map functions
protected:
	CString m_sName;
	CEditIrcMessageLine m_wndUserText;
	CRichEditCtrl m_wndMonitor;
	//{{AFX_MSG(CTryIRC2View)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	afx_msg LRESULT OnIrcMessageEdited(WPARAM, LPARAM);
	DECLARE_MESSAGE_MAP()

	void SetDefaultTextColor(COLORREF rgb);
};

#ifndef _DEBUG  // debug version in TryIRC2View.cpp
inline CTryIRC2Doc* CTryIRC2View::GetDocument()
   { return (CTryIRC2Doc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRYIRC2VIEW_H__368D93D8_A26C_4F61_8AA9_A7E4477613D0__INCLUDED_)
