// TryIRC2Doc.cpp : implementation of the CTryIRC2Doc class
//

#include "stdafx.h"
#include "TryIRC2.h"

#include "TryIRC2Doc.h"
#include "ConnectDlg.h"
#include "TryIRC2View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

DECLARE_IRC_MAP(CTryIRC2Doc, CIrcDefaultMonitor)

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2Doc

IMPLEMENT_DYNCREATE(CTryIRC2Doc, CDocument)

BEGIN_MESSAGE_MAP(CTryIRC2Doc, CDocument)
	//{{AFX_MSG_MAP(CTryIRC2Doc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2Doc construction/destruction

CTryIRC2Doc::CTryIRC2Doc()
	: irc::CIrcDefaultMonitor(g_ircSession), m_pSystemView(NULL)
{
	IRC_MAP_ENTRY(CTryIRC2Doc, "JOIN", OnIrc_JOIN)
	IRC_MAP_ENTRY(CTryIRC2Doc, "KICK", OnIrc_KICK)
	IRC_MAP_ENTRY(CTryIRC2Doc, "MODE", OnIrc_MODE)
	IRC_MAP_ENTRY(CTryIRC2Doc, "NICK", OnIrc_NICK)
	IRC_MAP_ENTRY(CTryIRC2Doc, "PART", OnIrc_PART)
	IRC_MAP_ENTRY(CTryIRC2Doc, "PRIVMSG", OnIrc_PRIVMSG)
	IRC_MAP_ENTRY(CTryIRC2Doc, "002", OnIrc_YOURHOST)
}

CTryIRC2Doc::~CTryIRC2Doc()
{
}

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2Doc serialization

void CTryIRC2Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2Doc diagnostics

#ifdef _DEBUG
void CTryIRC2Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CTryIRC2Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2Doc commands


BOOL CTryIRC2Doc::OnNewDocument()
{
	ASSERT(!g_ircSession);

	// currently we only have one view.
	// name it with the host's name
	POSITION pos = GetFirstViewPosition();
	ASSERT(pos);
	m_pSystemView = GetNextView(pos);

	CConnectDlg dlg;

	dlg.m_sServer = _T("irc.dalnet.org");
	dlg.m_uiPort = 6667;
	dlg.m_sNick = _T("TestUser2004");
	dlg.m_sUserID = _T("tt");
	dlg.m_sFullName = _T("tt");

	if( dlg.DoModal() != IDOK )
		return FALSE;

	// set this document object as the session's monitor
	g_ircSession.AddMonitor(this);

	CIrcSessionInfo si;
	si.sServer = dlg.m_sServer;
	si.iPort = dlg.m_uiPort;
	si.sNick = dlg.m_sNick;
	si.sUserID = dlg.m_sUserID;
	si.sFullName = dlg.m_sFullName;
	si.sPassword = dlg.m_sPassword;
	si.bIdentServer = true;
	si.iIdentServerPort = 113;
	si.sIdentServerType = "UNIX";

	bool m_bOk = g_ircSession.Connect(si);
	if( !m_bOk )
		return FALSE;

	SetTitle(g_ircSession.GetInfo().sNick.c_str());

	return TRUE;
}

void CTryIRC2Doc::DeleteContents() 
{
	g_ircSession.Disconnect();
	g_ircSession.RemoveMonitor(this);
	m_pSystemView = NULL;
	
	CDocument::DeleteContents();
}

////////////////////////////////////////////////////////////

bool CTryIRC2Doc::OnIrc_YOURHOST(const CIrcMessage* pmsg)
{
	CIrcDefaultMonitor::OnIrc_YOURHOST(pmsg);

	// currently we only have one view.
	// name it with the host's name
	ASSERT(m_pSystemView != NULL);
	((CTryIRC2View*)m_pSystemView)->SetName(
		g_ircSession.GetInfo().sServerName.c_str());
	m_pSystemView->GetParent()->SetWindowText(
		g_ircSession.GetInfo().sServerName.c_str());

	return false;
}

bool CTryIRC2Doc::OnIrc_NICK(const CIrcMessage* pmsg)
{
	CIrcDefaultMonitor::OnIrc_NICK(pmsg);

	if( pmsg->prefix.sNick == m_session.GetInfo().sNick && (pmsg->parameters.size() > 0) )
	{
	}

	return false;
}

bool CTryIRC2Doc::OnIrc_PRIVMSG(const CIrcMessage* pmsg)
{
	CString sName;
	if( pmsg->parameters[0][0] == '#' || !pmsg->m_bIncoming )
		sName = pmsg->parameters[0].c_str();
	else
		sName = pmsg->prefix.sNick.c_str();
		
	CTryIRC2View* pView = (CTryIRC2View*)FindView(sName);
	if( pView )
		pView->OnUpdate(NULL, (LPARAM)pmsg, NULL);

	return true;
}

bool CTryIRC2Doc::OnIrc_JOIN(const CIrcMessage* pmsg)
{
	CTryIRC2View* pView = (CTryIRC2View*)FindView(pmsg->parameters[0].c_str());
	if( pView )
		pView->OnUpdate(NULL, (LPARAM)pmsg, NULL);
	return true;
}

bool CTryIRC2Doc::OnIrc_PART(const CIrcMessage* pmsg)
{
	if( !pmsg->prefix.sNick.length() || pmsg->prefix.sNick == m_session.GetInfo().sNick )
		return false;
	CTryIRC2View* pView = (CTryIRC2View*)FindView(pmsg->parameters[0].c_str());
	if( pView )
		pView->OnUpdate(NULL, (LPARAM)pmsg, NULL);
	return true;
}

bool CTryIRC2Doc::OnIrc_KICK(const CIrcMessage* pmsg)
{
	if( !pmsg->prefix.sNick.length() )
		return false;
	CTryIRC2View* pView = (CTryIRC2View*)FindView(pmsg->parameters[0].c_str());
	if( pView )
		pView->OnUpdate(NULL, (LPARAM)pmsg, NULL);
	return true;
}

bool CTryIRC2Doc::OnIrc_MODE(const CIrcMessage* pmsg)
{
	if( !pmsg->prefix.sNick.length() )
		return false;
	if( pmsg->prefix.sNick == m_session.GetInfo().sNick )
		return false;
	CTryIRC2View* pView = (CTryIRC2View*)FindView(pmsg->parameters[0].c_str());
	if( pView )
		pView->OnUpdate(NULL, (LPARAM)pmsg, NULL);
	return true;
}

void CTryIRC2Doc::OnIrcDefault(const CIrcMessage* pmsg)
{
	CIrcDefaultMonitor::OnIrcDefault(pmsg);

	if( pmsg && m_session.GetInfo().sServerName.length() )
	{
		CTryIRC2View* pView = (CTryIRC2View*)FindView(
						m_session.GetInfo().sServerName.c_str());
		if( pView )
			pView->OnUpdate(NULL, (LPARAM)pmsg, NULL);
	}
	else
		UpdateAllViews(NULL, (LPARAM)pmsg);
}

void CTryIRC2Doc::OnIrcDisconnected()
{
	AfxGetMainWnd()->PostMessage(WM_COMMAND, ID_FILE_CLOSE);
}



CView* CTryIRC2Doc::FindView(LPCTSTR lpszName)
{
	POSITION pos = GetFirstViewPosition();
	while( pos )
	{
		CTryIRC2View* pView = (CTryIRC2View*)GetNextView(pos);

		if( strcmpi(pView->GetName(), lpszName) == 0 )
			return pView;
	}

	return CreateNewView(lpszName);
}

CView* CTryIRC2Doc::CreateNewView(LPCTSTR lpszName)
{
	CDocTemplate* pTmp = GetDocTemplate();
	CFrameWnd* pFrame = pTmp->CreateNewFrame(this, NULL);
	ASSERT(pFrame != NULL);
	pFrame->SetWindowText(lpszName);
	pFrame->ActivateFrame();
	pFrame->ShowOwnedWindows(TRUE);

	POSITION pos = GetFirstViewPosition();
	while( pos )
	{
		CTryIRC2View* pView = (CTryIRC2View*)GetNextView(pos);

		if( !pView->GetName() || !lstrlen(pView->GetName()) )
		{
			pView->SetName(lpszName);
			pView->SetWindowText(lpszName);
			return pView;
		}
	}
	 
	return NULL;
}


