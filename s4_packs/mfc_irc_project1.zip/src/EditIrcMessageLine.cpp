// EditIrcMessageLine.cpp : implementation file
//

#include "stdafx.h"
#include "TryIRC2.h"
#include "EditIrcMessageLine.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditIrcMessageLine

CEditIrcMessageLine::CEditIrcMessageLine()
{
}

CEditIrcMessageLine::~CEditIrcMessageLine()
{
}


BEGIN_MESSAGE_MAP(CEditIrcMessageLine, CEdit)
	//{{AFX_MSG_MAP(CEditIrcMessageLine)
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditIrcMessageLine message handlers

void CEditIrcMessageLine::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	CEdit::OnKeyDown(nChar, nRepCnt, nFlags);

	if( nChar == VK_RETURN )
	{
		GetParent()->PostMessage(IRCEDN_RETURNPRESSED);
	}
}
